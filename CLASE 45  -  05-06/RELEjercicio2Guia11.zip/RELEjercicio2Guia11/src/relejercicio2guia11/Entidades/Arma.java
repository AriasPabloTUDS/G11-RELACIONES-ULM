/*
 Clase Revolver de agua: esta clase posee los siguientes atributos: posición actual (posición
del tambor que se dispara, puede que esté el agua o no) y posición agua (la posición del
tambor donde se encuentra el agua). Estas dos posiciones, se generarán aleatoriamente.
 */
package relejercicio2guia11.Entidades;

public class Arma {
    private Integer posAct;
    private Integer posH2o;

    public Integer getPosAct() {
        return posAct;
    }

    public void setPosAct(Integer posAct) {
        this.posAct = posAct;
    }

    public Integer getPosH2o() {
        return posH2o;
    }

    public void setPosH2o(Integer posH2o) {
        this.posH2o = posH2o;
    }

    @Override
    public String toString() {
        return "Arma{" + "posAct=" + posAct + ", posH2o=" + posH2o + '}';
    }
    
    
    
}
