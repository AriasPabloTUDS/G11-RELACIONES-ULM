/*
 Métodos:
• disparo(Revolver r): el método, recibe el revolver de agua y llama a los métodos de
mojar() y siguienteChorro() de Revolver. El jugador se apunta, aprieta el gatillo y si el
revolver tira el agua, el jugador se moja. El atributo mojado pasa a false y el método
devuelve true, sino false.
 */
package relejercicio2guia11.Entidades.Servicios;

import relejercicio2guia11.Entidades.Arma;
import relejercicio2guia11.Entidades.Jugador;

public class JugadorServicio {

    ArmaServicio AS;
    Jugador J;
    
    public JugadorServicio() {
        AS = new ArmaServicio();
    }
    
    public boolean disparo(Arma r) {
        boolean disparo = AS.mojar();
        AS.siguienteChorro();
        J.setMojado(!disparo);
        System.out.println("El jugador se mojo? "+disparo);
        return disparo;
    }
    
}
