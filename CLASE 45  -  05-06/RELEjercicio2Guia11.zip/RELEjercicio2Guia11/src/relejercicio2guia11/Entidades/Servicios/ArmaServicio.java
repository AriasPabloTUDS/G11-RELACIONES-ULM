/*
 Métodos:
• llenarRevolver(): le pone los valores de posición actual y de posición del agua. Los valores
deben ser aleatorios.
• mojar(): devuelve true si la posición del agua coincide con la posición actual
• siguienteChorro(): cambia a la siguiente posición del tambor
• toString(): muestra información del revolver (posición actual y donde está el agua)
 */
package relejercicio2guia11.Entidades.Servicios;

import relejercicio2guia11.Entidades.Arma;

public class ArmaServicio {

    private Arma revolver;

    public ArmaServicio() {
        revolver = new Arma();
    }

    public void llenarRevolver() {
        Integer posran1 = (int) (Math.random() * 6 + 1);
        Integer posran2 = (int) (Math.random() * (6)) + 1;
        //  System.out.println("PosAct= "+posran1+" PosH2o= "+posran2);
        revolver.setPosAct(posran1);
        revolver.setPosH2o(posran2);
    }

    public Boolean mojar() {
        Boolean mojar;
        if (revolver.getPosAct() == revolver.getPosH2o()) {
            mojar = true;
        } else {
            mojar = false;
        }
        return mojar;
    }

    public void siguienteChorro() {
        if (revolver.getPosAct() == 6) {
            revolver.setPosAct(1);
        } else {
            revolver.setPosAct(revolver.getPosAct() + 1);
        }
    }

    public void mostraposiciones() {
        System.out.println("PosAct= " + revolver.getPosAct() + " PosH2o= " + revolver.getPosH2o());
    }

}
