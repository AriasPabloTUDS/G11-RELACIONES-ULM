/*
Clase Juego: esta clase posee los siguientes atributos: Jugadores (conjunto de Jugadores) y
Revolver
 */
package relejercicio2guia11.Entidades;

import java.util.ArrayList;


public class Juego {
    private ArrayList<Jugador> jugador;
    private Arma revolver;

    public ArrayList<Jugador> getJugador() {
        return jugador;
    }

    public void setJugador(ArrayList<Jugador> jugador) {
        this.jugador = jugador;
    }

    public Arma getRevolver() {
        return revolver;
    }

    public void setRevolver(Arma revolver) {
        this.revolver = revolver;
    }

    
    @Override
    public String toString() {
        return "Juego{" + "jugador=" + jugador + ", revolver=" + revolver + '}';
    }
    
    
}
